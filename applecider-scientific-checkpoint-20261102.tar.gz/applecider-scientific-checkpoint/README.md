# Scientific checkpoint

This is an intentionally incomplete confirmation checkpoint. All 4096 captured confirmation sessions are retained; four controller shards were stopped at the user request before the complete 262144-row grid. Do not treat partial confirmation rows as confirmatory estimates or inflate N by adding interrupted attempts. No empirical-prior confirmation replay, literal confirmation replay or final confirmation analyses were executed.

Design diagnostics, failed exact-DP rows, tune captures, selected orders/prior, current executable source and historical design/tune scripts are included. Raw outcome and snapshot files are byte exact; portable resource/manifest projections explicitly retain original artifact hashes in inventory.json. No model binaries or full external event data are bundled. All imposed policy costs are separate from measured acquisition/replay resources.

To resume later, validate inventory hashes and retain both attempts as immutable records. Prefer a newly named, uniform full replay from the saved confirmation snapshots with the frozen configuration and explicit prior, followed by complete Cartesian validation and exact overlap comparison excluding only replay_controller_wall_seconds. Never refit or select between attempts. The complete public commands and analysis helpers are in the source scripts; configuration files are in configuration/. Original captures are in captures/confirmation/snapshots/. Upstream FLARE/LUNA/data/model dependencies still need the recorded environment; this archive is not a self-contained model installation.

This local checkpoint has not been published as a permanent data archive.
